﻿window.PlayAudio = (element) => {
    document.getElementById(element).play();
}